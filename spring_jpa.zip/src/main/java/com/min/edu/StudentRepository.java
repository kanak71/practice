package com.min.edu;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.min.edu.entity.StudentEntity;

//TODO 003 StudentEntity에 CRUD를 위한 JpaRepository
@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Long> {

}
